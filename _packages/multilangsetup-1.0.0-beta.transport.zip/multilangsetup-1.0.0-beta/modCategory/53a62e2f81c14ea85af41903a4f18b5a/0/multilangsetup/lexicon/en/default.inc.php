<?php
/**
 * Default English Lexicon Entries for MultiLangSetup
 *
 * @package multilangsetup
 * @subpackage lexicon
 */

$_lang['multilangsetup'] = 'MultiLangSetup';

